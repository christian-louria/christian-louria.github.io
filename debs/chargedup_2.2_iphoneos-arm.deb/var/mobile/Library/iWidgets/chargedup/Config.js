/*
Configurations
Credits: Original code by Dacal & Junesiphone. Modified by Evelyn.
*/

var Color = "white";  // choose a color
