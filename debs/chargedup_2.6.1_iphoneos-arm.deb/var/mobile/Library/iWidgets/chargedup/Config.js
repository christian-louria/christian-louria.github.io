/*
Configurations
Credits: Tian
*/

var Color = "green";  // choose a color
