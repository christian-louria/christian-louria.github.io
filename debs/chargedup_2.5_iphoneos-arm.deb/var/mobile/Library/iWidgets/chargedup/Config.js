/*
Configurations
Credits: Tian
*/

var Color = "red";  // choose a color
