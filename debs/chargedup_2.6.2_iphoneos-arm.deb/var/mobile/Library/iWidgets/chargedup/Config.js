/*
Configurations
Credits: Tian
*/

var Color = "green";  // choose a color HEX or basic color

var Sides = "true";